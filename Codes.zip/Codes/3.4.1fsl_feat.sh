#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.4singlesubject/Design;

j=1;

while [ $j -le 33 ]; do

  sn=`zeropad $j 2`;

  for task in Task1 Task2 Task3; do
    vols=`fslval /Users/mingzhang/Documents/FSL/3Analyse/3.4singlesubject/Sub${sn}/Sub${sn}_${task} dim4`; #fslval - report a particular parameter (given a particular keyword eg "dim4") from an image header
    echo Sub$sn $vols $task;
    cat $datadir/Template_new.fsf | sed s/SUBJECT/Sub${sn}/g | sed s/TASK/${task}/g | sed s/VOLUMES/"${vols}"/g > $datadir/Sub${sn}_${task}.fsf;#s/表达式/替换字符串/g：将表达式的内容替换为后面的字符串,g表示替换全部
    feat $datadir/Sub${sn}_${task}.fsf; #执行，相当于FEAT GUI的go
    cat $datadir/Rating_new.fsf | sed s/SUBJECT/Sub${sn}/g | sed s/TASK/${task}/g | sed s/VOLUMES/"${vols}"/g > $datadir/Sub${sn}_${task}_rating.fsf;
    feat $datadir/Sub${sn}_${task}_rating.fsf;
  done
  j=`echo $j + 1 | bc`;

done
