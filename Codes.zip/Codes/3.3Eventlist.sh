#!/bin/sh
# 1.Subject 2.Run 3.Condition(1Stigma 2Neutral) 4.Level(42low 45high)
# 5.Pain ratings 6.Condition Time 7.Stimulus Onset 8. Response onset

line_total=`wc subject.txt | awk {'print $1'}`;
#wc(Word Count)命令的功能为统计指定文件中的字节数、字数、行数;
#awk:逐行扫描文件（从第 1 行到最后一行），寻找含有目标文本的行，如果匹配成功，则会在该行上执行用户想要的操作；反之，则不对行做任何处理
#print $1:输出文本的第1项，其实就是某一行第1列的内容

l=1;
while [ $l -le $line_total ] ; do

  s=`awk 'NR=='$l' {print $1}' subject.txt`; #NR:已经读出的记录数，就是行号，从1开始,txt文本中第1列是被试编号
  sub=`zeropad $s 2`;

  run=`awk 'NR=='$l' {print $2}' subject.txt`; # txt文本中第2列是run号
  condition=`awk 'NR=='$l' {print $3}' subject.txt`; # txt文本中第3列是condition：stigma vs neutral
  intensity=`awk 'NR=='$l' {print $4}' subject.txt`; # txt文本中第4列是疼痛刺激强度，42度或45度
  painrating=`awk 'NR=='$l' {print $5}' subject.txt`; # txt文本中第5列是被试的疼痛评分
  conditiontime=`awk 'NR=='$l' {print $6}' subject.txt`; # txt文本中第6列是图片开始的时间
  stimulitime=`awk 'NR=='$l' {print $7}' subject.txt`; # txt文本中第7列是疼痛刺激开始的时间
  responsetime=`awk 'NR=='$l' {print $8}' subject.txt`; # txt文本中第8列是被试做反应开始的时间

  echo $conditiontime 4 1 >> Sub${sub}_${run}_${condition}.txt; #onset(s), duration(s), the value of the input
  echo $stimulitime 4 1 >> Sub${sub}_${run}_${intensity}.txt;
  echo $responsetime 5 1 >> Sub${sub}_${run}_rating.txt;
  echo $stimulitime 4 1 >> Sub${sub}_${run}_${condition}_${intensity}.txt;
  echo $stimulitime 4 $painrating >> Sub${sub}_${run}_${condition}_${intensity}_rating.txt;

  l=`echo $l + 1 | bc`; #bc 是运算表达式，表示j+1可运行
done
# 注意检查最后一个被试的时间全不全！！！
