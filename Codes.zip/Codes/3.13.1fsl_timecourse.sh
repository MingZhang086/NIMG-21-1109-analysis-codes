#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.4singlesubject;

j=1;

while [ $j -le 33 ]; do

  sn=`zeropad $j 2`;

    for task in Task1 Task2 Task3; do

      echo Sub$sn $task;

      cd $datadir/Sub${sn}/Sub${sn}_${task}.feat/reg;

      invwarp -w highres2standard_warp -o standard2highres_warp -r highres;
      applywarp -i $datadir/dACC_activited -r example_func -o dACC_activitedFunc \
  -w standard2highres_warp --postmat=highres2example_func.mat;
      fslmaths dACC_activitedFunc -thr 0.9 -bin dACC_activitedFuncBin;
      fslmeants -i $datadir/Sub${sn}/Sub${sn}_${task}.feat/filtered_func_data -o my_timecourse.txt -m dACC_activitedFuncBin;


    done

    j=`echo $j + 1 | bc`;

  done
