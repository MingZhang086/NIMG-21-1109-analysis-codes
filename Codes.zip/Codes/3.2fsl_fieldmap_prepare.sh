#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/2Convert/2.2Fieldmap;
outdir=/Users/mingzhang/Documents/FSL/3Preprocessing/3.2fieldmap;

j=1;

while [ $j -le 33 ]; do

sn=`zeropad $j 2`;
mkdir -p $outdir/Sub${sn}; #-p, --parents no error if existing, make parent directories as needed
echo $outdir/Sub${sn};

cp $datadir/Sub${sn}/Sub${sn}_fieldmap_e2.nii.gz $outdir/Sub${sn}/fieldmap_mag.nii.gz; #原始文件中第1个fieldmap文件的第2个像做mag,第2个fieldmap文件是phase像
cp $datadir/Sub${sn}/Sub${sn}_fieldmap_e2_ph.nii.gz $outdir/Sub${sn}/fieldmap_ph.nii.gz;

# precess Fieldmap mag
bet $outdir/Sub${sn}/fieldmap_mag.nii.gz  $outdir/Sub${sn}/fieldmap_mag_brain.nii.gz; #brain extraction
fslmaths $outdir/Sub${sn}/fieldmap_mag_brain.nii.gz  -ero $outdir/Sub${sn}/fieldmap_mag_brain_ero.nii.gz

# fsl_prepare_fieldmap <scanner> <phase_image> <magnitude_image> <out_image> <deltaTE (in ms)> [--nocheck]
fsl_prepare_fieldmap SIEMENS $outdir/Sub${sn}/fieldmap_ph.nii.gz $outdir/Sub${sn}/fieldmap_mag_brain_ero.nii.gz $outdir/Sub${sn}/fieldmap_rads.nii.gz 2.46;

j=`echo $j + 1 | bc`;

done
