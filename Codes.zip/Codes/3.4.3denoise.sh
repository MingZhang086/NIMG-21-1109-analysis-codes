#!/bin/sh
datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.4singlesubject;

j=1;

while [ $j -le 33 ]; do

sn=`zeropad $j 2`;

  for task in Task1 Task2 Task3; do

    echo Sub$sn $task;

    noise=`tail -1 $datadir/Sub${sn}/Sub${sn}_${task}.feat/filtered_func_data.ica/noise.txt | sed 's/\]//g' | sed 's/ //g' | sed 's/\[//g'`;

    fsl_regfilt -i $datadir/Sub${sn}/Sub${sn}_${task}.feat/filtered_func_data -d $datadir/Sub${sn}/Sub${sn}_${task}.feat/filtered_func_data.ica/melodic_mix -o $datadir/Sub${sn}/Sub${sn}_${task}.feat/denoise_data.nii.gz -f $noise

  done

j=`echo $j + 1 | bc`; #bc 是运算表达式，表示j+1可运行

done
