#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/2Convert/1T1;
outdir=/Users/mingzhang/Documents/FSL/3Preprocessing/1T1;

j=1;

while [ $j -le 33 ]; do #-le means <=

sn=`zeropad $j 2`; #means: The default is to give you classic padding behavior where numbers less than 10 are padded with a single zero, eg.'9' → '09'

cp $datadir/Sub${sn}/Sub${sn}_T1.nii.gz $outdir/Sub${sn}_T1.nii.gz;

fsl_anat -i $outdir/Sub${sn}_T1 --noreg --nononlinreg --noseg --nosubcortseg --betfparam=0.4; #-i means input image direction, check function fsl_anat in terminal to know what have done

j=`echo $j + 1 | bc`; #bc 是运算表达式，表示j+1可运行

done
