#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.6Group_ttest_all/corrected2.3/Design;

sn=1;

while [ $sn -le 25 ]; do

    echo cope$sn;
    cat $datadir/template_3rd.fsf | sed s/COPE/cope${sn}/g > $datadir/cope${sn}_group.fsf;
    feat $datadir/cope${sn}_group.fsf;
    cat $datadir/template_3rd_rating.fsf | sed s/COPE/cope${sn}/g > $datadir/cope${sn}_group_rating.fsf;
    feat $datadir/cope${sn}_group_rating.fsf;
    sn=`echo $sn + 1 | bc`;

done
