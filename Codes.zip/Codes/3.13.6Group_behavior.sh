#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.13PPI/4Group_behavior/Design;

sn=1;

while [ $sn -le 28 ]; do

    echo cope$sn;
    cat $datadir/template_3rd_correlatedbehavior.fsf | sed s/COPE/cope${sn}/g > $datadir/cope${sn}_group.fsf;
    feat $datadir/cope${sn}_group.fsf;

    sn=`echo $sn + 1 | bc`;

done
