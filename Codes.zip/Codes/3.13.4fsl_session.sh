#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.13PPI/4Pain_nostalgia-control/2Pain_control/2Sessionsmerge/Design;

j=1;

while [ $j -le 33 ]; do

  sn=`zeropad $j 2`;

    echo Sub$sn;
    cat $datadir/Template_2nd.fsf | sed s/SUBJECT/Sub${sn}/g > $datadir/Sub${sn}_2nd.fsf;
    feat $datadir/Sub${sn}_2nd.fsf;

  j=`echo $j + 1 | bc`;

done
