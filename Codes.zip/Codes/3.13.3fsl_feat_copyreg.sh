#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.4singlesubject;

j=1;

while [ $j -le 33 ]; do

  sn=`zeropad $j 2`;

  for task in Task1 Task2 Task3; do

    echo Sub$sn $task;

    cp -r /Users/mingzhang/Documents/FSL/3Analyse/3.4singlesubject/Sub${sn}/Sub${sn}_${task}.feat/reg  /Users/mingzhang/Documents/FSL/3Analyse/3.13PPI/4Pain_nostalgia-control/2Pain_control/1Singlesubject/Sub${sn}/Sub${sn}_${task}.feat/

  done

  j=`echo $j + 1 | bc`;

done
