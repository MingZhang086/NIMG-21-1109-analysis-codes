#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.13PPI/4Pain_nostalgia-control/2Pain_control/1Singlesubject/Design;

j=13;

while [ $j -le 33 ]; do

  sn=`zeropad $j 2`;

  for task in Task1 Task2 Task3; do
    vols=`fslval /Users/mingzhang/Documents/FSL/3Analyse/3.4singlesubject/Sub${sn}/Sub${sn}_${task} dim4`;
    echo Sub$sn $vols $task;
    cat $datadir/Template.fsf | sed s/SUBJECT/Sub${sn}/g | sed s/TASK/${task}/g | sed s/VOLUMES/"${vols}"/g > $datadir/Sub${sn}_${task}.fsf;
    feat $datadir/Sub${sn}_${task}.fsf;

  done

  j=`echo $j + 1 | bc`;

done
