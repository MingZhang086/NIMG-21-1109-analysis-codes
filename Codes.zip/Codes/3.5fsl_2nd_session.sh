#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.5sessionsmerge/Design;

j=1;

while [ $j -le 33 ]; do

  sn=`zeropad $j 2`;

    echo Sub$sn;
    cat $datadir/Template_2nd.fsf | sed s/SUBJECT/Sub${sn}/g > $datadir/Sub${sn}_2nd.fsf;
    feat $datadir/Sub${sn}_2nd.fsf;
    cat $datadir/Template_2nd_rating.fsf | sed s/SUBJECT/Sub${sn}/g > $datadir/Sub${sn}_2nd_rating.fsf;
    feat $datadir/Sub${sn}_2nd_rating.fsf;

  j=`echo $j + 1 | bc`;

done
