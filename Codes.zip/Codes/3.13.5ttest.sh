#!/bin/sh

datadir=/Users/mingzhang/Documents/FSL/3Analyse/3.13PPI/4Cue_nostalgia-control/1Cue_nostalgia/3Ttest_all/Design;

sn=1;

while [ $sn -le 28 ]; do

    echo cope$sn;
    cat $datadir/template_3rd.fsf | sed s/COPE/cope${sn}/g > $datadir/cope${sn}_group.fsf;
    feat $datadir/cope${sn}_group.fsf;

    sn=`echo $sn + 1 | bc`;

done
